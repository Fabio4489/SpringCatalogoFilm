package com.example.CatalogoFilm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoFilmApplicationTests {

	@Test
	void contextLoads() {
	}

}
